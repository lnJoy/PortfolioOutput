package com.portfolio.portfoliooutput;

public class DataList {
    public static String longex;
    public static String caution;
    public static String youtubeid;
    public static String email;

    public static String picture;
}
