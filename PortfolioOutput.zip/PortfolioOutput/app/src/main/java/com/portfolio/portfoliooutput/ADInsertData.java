package com.portfolio.portfoliooutput;

public class ADInsertData {
    private String member_title;
    private String member_adex;
    private String member_youtubeid;
    private String member_email;
    private String member_longex;
    private String member_caution;
    private String member_startdate;
    private String member_enddate;


    public String getMember_title() {
        return member_title;
    }

    public String getMember_adex() {
        return member_adex;
    }

    public String getMember_youtubeid() {
        return member_youtubeid;
    }

    public String getMember_email() {
        return member_email;
    }

    public String getMember_longex() {
        return member_longex;
    }

    public String getMember_caution() {
        return member_caution;
    }

    public String getMember_startdate() {
        return member_startdate;
    }

    public String getMember_enddate() {
        return member_enddate;
    }

    public void setMember_title(String member_title) {
        this.member_title = member_title;
    }

    public void setMember_adex(String member_adex) {
        this.member_adex = member_adex;
    }

    public void setMember_youtubeid(String member_youtubeid) {
        this.member_youtubeid = member_youtubeid;
    }

    public void setMember_email(String member_email) {
        this.member_email = member_email;
    }

    public void setMember_longex(String member_longex) {
        this.member_longex = member_longex;
    }

    public void setMember_caution(String member_caution) {
        this.member_caution = member_caution;
    }

    public void setMember_startdate(String member_startdate) {
        this.member_startdate = member_startdate;
    }

    public void setMember_enddate(String member_enddate) {
        this.member_enddate = member_enddate;
    }
}